This directory contains stub files which implements parts of UModel's core using STL. Should either copy these files
into UI library's directory, or put path to this directory into compiler's include directories.

Additional build requirements which are not here, but exists in UModel project: callback.hpp, Win32Types.h
