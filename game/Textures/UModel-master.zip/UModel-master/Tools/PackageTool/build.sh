#!/bin/bash

project="pkgtool"
root="../.."
render=0
source $root/build.sh
