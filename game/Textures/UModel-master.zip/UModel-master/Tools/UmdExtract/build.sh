#!/bin/bash

project="unumd"
root="../.."
render=0
source $root/build.sh
