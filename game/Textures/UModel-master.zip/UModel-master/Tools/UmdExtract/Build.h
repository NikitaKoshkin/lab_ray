#define DO_GUARD		1

//#define UNREAL1			1
#define UNREAL25		1
#define UNREAL3			1		// for compression functions only
#define XBOX360			1		// XBox360 compression support

#define LEAD			1
