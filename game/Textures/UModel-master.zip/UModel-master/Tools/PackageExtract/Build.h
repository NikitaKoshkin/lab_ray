#define DO_GUARD		1

// Use all supported games
#include "GameDefines.h"
