#ifndef __PACKAGE_SCAN_DIALOG_H__
#define __PACKAGE_SCAN_DIALOG_H__


void ShowPackageScanDialog();


#endif // __PACKAGE_SCAN_DIALOG_H__
